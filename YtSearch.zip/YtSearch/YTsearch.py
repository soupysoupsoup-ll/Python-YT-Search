import webbrowser
searchq = input("Search on YouTube for: ")
result = searchq.replace(" ", "+")
webbrowser.open("www.youtube.com/results?search_query=" + result)